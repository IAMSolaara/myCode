#ifndef READ_S
#define READ_S

#include <stdio.h>

void readS(char* s, int len);
int freadS(FILE* f, char* s, int len);

#endif
